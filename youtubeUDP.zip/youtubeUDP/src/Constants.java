public class Constants {

    public static final int PORT=5554;
    public static final int BUFFER_SIZE=1024;
    public static final String Stop="Bye";
}
